@echo off
title Digital Forensic Simulation
color 0A

echo.
echo =========================================
echo          DIGITAL FORENSIC LAB
echo =========================================
echo.

set LOGDIR=%~dp0Evidence

if not exist "%LOGDIR%" (
    mkdir "%LOGDIR%"
)

(
echo ================================
echo Digital Forensic Simulation Log
echo ================================
echo Date       : %DATE%
echo Time       : %TIME%
echo User       : %USERNAME%
echo Computer   : %COMPUTERNAME%
echo File Path  : %~dp0
echo ================================
) > "%LOGDIR%\execution.log"


echo Membuka simulasi...
timeout /t 2 >nul


:: Memutar video yang berada satu folder
start "" "a.mp4"


:: Membuat artefak tambahan untuk analisis
echo Simulation executed > "%LOGDIR%\activity.txt"
echo Video opened at %TIME% >> "%LOGDIR%\activity.txt"


echo.
echo =========================================
echo       SIMULASI SELESAI
echo =========================================
echo.
echo Artefak tersimpan di:
echo %LOGDIR%
echo.

pause